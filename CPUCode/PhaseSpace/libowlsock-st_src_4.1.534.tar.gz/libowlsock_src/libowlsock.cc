// libowlsock.cc
// network enabled OWL library, using OWLContext (thread safe)
// OWL v1.3

#include <iostream>
#include <stdio.h>
#include <assert.h>
#include <errno.h>
#include <vector>
#include <deque>
#include <string>
#include <algorithm>

#ifdef WIN32
#include <io.h>
#endif

#include "owl_ctx.h"
#include "owl.h"
#include "owl_peaks.h"
#include "owl_images.h"
#include "owl_planes.h"
#include "owl_rpd.h"
#include "owl_protocol.h"
#include "owl_math.h"
#include "net_utils.h"
#include "buffer.h"
#include "c3d_file.h"
#include "timer.h"
#include "utils.h"
#include "interp.h"

using namespace std;

#define DBG(msg)// msg
#define DBG2(msg)// msg

// tmp
#define OWL_SYNTHETIC_2D 0x02DE
#define OWL_SYNTHETIC_3D 0x02DF

Timer timer;

struct OWLFloats {
  typedef float type;
  OWLenum pname;
  int frame;
  vector<float> data;
  OWLFloats(OWLenum pname, int frame) : pname(pname), frame(frame) { }
};

struct OWLIntegers {
  typedef int type;
  OWLenum pname;
  int frame;
  vector<int> data;
  OWLIntegers(OWLenum pname, int frame) : pname(pname), frame(frame) { }
};

struct OWLString {
  typedef char type;
  OWLenum pname;
  int frame;
  vector<char> data;
  OWLString(OWLenum pname, int frame) : pname(pname), frame(frame) { }
};

#define OPERATOR_EQ(T) bool operator==(const T &a, const T &b) { return a.pname == b.pname; }

OPERATOR_EQ(OWLFloats);
OPERATOR_EQ(OWLIntegers);
OPERATOR_EQ(OWLString);

#undef CTX
#define CTX(c) assert(c); assert(c == c->self); \
_OWLState &_owl = c->owl; (void)_owl;\
_OWLClient &_client = c->client, &_broadcast = c->broadcast; (void)_client; (void)_broadcast;\
_RPDClient &_rpd_client = c->rpd_client; (void)_rpd_client;

typedef deque<OWLEvent> Events;
typedef deque<int> Errors;
typedef deque< vector<OWLMarker> > Markers;
typedef deque< vector<OWLRigid> > Rigids;
typedef vector<OWLCamera> Cameras;
typedef deque<OWLFloats> Floats;
typedef deque<OWLIntegers> Integers;
typedef deque<OWLString> Strings;
typedef deque< vector<OWLPeak> > Peaks;
typedef deque< vector<OWLDetectors> > Detectors;
typedef deque< vector<OWLPlane> > Planes;

inline OWLMarker Marker(int id, int frame, float x, float y, float z, float cond, uint_t flag)
{
  OWLMarker m;
  m.id = id;
  m.frame = frame;
  m.x = x;
  m.y = y;
  m.z = z;
  m.cond = cond;
  m.flag = flag;
  return m;
}

//// _RPDClient ////

struct _RPDClient : public buffer<char> {

  socket_t sock;
  int fd;
  int _mode;

  int _write, _read, _send, _recv, _max_size;

  _RPDClient(size_t buffer_size, size_t erase_delay) : 
    buffer<char>(buffer_size, erase_delay), sock(-1), fd(-1), _mode(0), 
    _write(0), _read(0), _send(0), _recv(0), _max_size(0) { }
  ~_RPDClient() { Close(); }

  int Open(const char *servername, const char *filename, int mode);
  void Disconnect();
  void Close();
  int Send(int retry=0, size_t count=0);
  int Recv();
};

struct RecordState {
  size_t startTime;
  size_t index;
  float freq;  

  vector< vector<OWLMarker> > frames;

  RecordState()
    : startTime(0), index(0), freq(0)
  {}

  int Init(const char *server)
  {
    Reset();
    cout << "loading c3d file; " << server << endl;
    int ret = load_c3d(server, frames);
    
    if(ret > 0)
      {
        ret = frequency_c3d(server, &freq);
        index = 0;
        startTime = timer;

        cout << "c3d loaded: frames=" << frames.size() << " @ " << freq << "Hz" << endl;
      }

    return ret;
  }

  void Reset()
  {
    startTime = index = 0;
    freq = 0;
    frames.clear();
  }

  bool frameAvailable()
  {
#if 0    
    size_t now = timer;
    size_t totalTime = now - startTime;
    size_t frameTime = (size_t)((1 / freq) * 1000000);
    size_t totalFramesDesired = totalTime / frameTime;

    return index < totalFramesDesired;
#else
    return ( index < ((timer.get() - startTime) / (((1.0 / freq) * 1000000.0))) );
#endif
  }
};

//// _OWLState ////

struct _OWLState {

  // client state
  int init; // 0x10 -- fully initialized
  int flags;

  size_t connectTime;

  string server;

  float pose[7];
  float scale;
  float m[16];
  float m_1[16]; // inverse

  // pose stack
  // [0] core transform
  // [1] client transform
  float p_stack[2][7];

  int frameNumber;
  int exiting;
  OWLenum lastAck;

  int enableEvents;
  int frameBufferSize;

  Events events;
  Errors errors;
  Markers markers;
  Rigids rigids;
  Cameras cameras;
  Floats floats;
  Integers integers;
  Strings strings;
  Peaks peaks;
  Detectors detectors;
  Planes planes;

  // file support
  RecordState recState;

  // interpolation
  int interp;
  vector<OWLMarker> past;

  _OWLState()
  {
    InitClientState();
  }
  
  operator void*() { return init == 0x10 ? (void*)(-1) : (void*)0; }
  int operator!() { return init == 0x10 ? 0 : 1; }

  void InitClientState()
  {
    init = 0;
    flags = 0;

    connectTime = 0;

    server.clear();

    for(int i = 0; i < 7; i++)
      pose[i] = p_stack[0][i] = p_stack[1][i] = 0;
    pose[3] = p_stack[0][3] = p_stack[1][3] = 1;
    scale = 1;
    convert_pm(pose, m);
    convert_pmi(pose, m_1);
    
    frameNumber = 0;
    exiting = 0;
    lastAck = 0;

    enableEvents = 0;
    frameBufferSize = 1000;

    events.clear();
    errors.clear();
    markers.clear();
    rigids.clear();
    cameras.clear();
    floats.clear();
    integers.clear();
    strings.clear();
    peaks.clear();
    detectors.clear();
    planes.clear();
    recState.Reset();

    interp = 0;
    past.clear();
  }

  int IsEmpty()
  {
    int n = 0
      + (enableEvents ? events.size() : 0)
      + markers.size()
      + rigids.size()
      + peaks.size()
      + detectors.size()
      + planes.size()
      ;

    return n == 0;
  }

  template <class T>
  bool dataReady(const deque< vector<T> > &t)
  {
    return (t.size() && t.front().size() && (exiting || !interp || (t.front().front().frame <= (frameNumber - interp))));
  }

  void updateInterp(const vector<OWLMarker> &current)
  {
    if(!interp || (int)markers.size() < interp+1) return;

     // e.g. size=7, interp=3, then front = (7 - 1) - 3 = 3
    int front = (markers.size() - 1) - interp;

    if(markers[front].size() != current.size())
      {
        cout << " current frame has different number of markers than past... skipping." << endl;
        return;
      }

    for(size_t i = 0; i < current.size(); i++)
      {
        const OWLMarker &frontmarker = markers[front][i];

        // assume marker indices do not change (but check overflow anyway)
        vector<OWLMarker> points;
        if(!findPoints(points, frontmarker, i)) continue;

        // submit these points to the interplation function
        vector<OWLMarker> results;
        if(calculate(points, results, frontmarker))
          {
            // copy results over source data
            applyPoints(results, i);
          }
      }
  }

  int findPoints(vector<OWLMarker> &points, const OWLMarker &frontmarker, int idx)
  {
    // if the "front" marker is not valid, we don't bother
    if(frontmarker.cond <= 0 || (frontmarker.flag & 0x10)) return 0;

    // use past marker if within range
    if(idx < (int)past.size())
      {
        const OWLMarker &m = past[idx];
        if(m.cond > 0 && m.id == frontmarker.id && frontmarker.frame - m.frame <= interp*3)
          {
            DBG2(cout << "(" << m.frame << ") ");
            points.push_back(m);
          }
      }

     // e.g. size=7, interp=3, then front = (7 - 1) - 3 = 3
    int front = (markers.size() - 1) - interp;

    DBG2(cout << "[");
    for(int i = front; i < (int)markers.size(); i++)
      {
        const OWLMarker &m = markers[i][idx];
        if(m.id != frontmarker.id || m.cond <= 0 || (m.flag & 0x10)) continue;
        points.push_back(m);
        DBG2(cout << " " << points.back().frame);

        // replace past marker w/ valid front-most marker
        if(i == front)
          {
            if(idx >= (int)past.size()) past.resize(idx+1);
            past[idx] = m;
          }
      }
    DBG2(cout << " ]" << endl);

    return points.size() > 1;
  }

  int calculate(const vector<OWLMarker> &points, vector<OWLMarker> &result, const OWLMarker &frontmarker)
  {
    if(points.size() == 2) return doLerp(points, result, frontmarker);
    if(points.size() == 3 || frontmarker.frame == points.front().frame) return doQuadratic(points, result, frontmarker);
    return doCubic(points, result, frontmarker);

    return 1;
  }
  
  int doLerp(const vector<OWLMarker> &points, vector<OWLMarker> &out, const OWLMarker &front)
  {
    if(points.size() < 2 ||
       points[0].id != points[1].id ||
       points[0].frame == points[1].frame) return 0;

    // do not use past marker for lerp
    if(points[0].frame != front.frame) return 0;

    float t_scale = points[1].frame - points[0].frame;
    if(t_scale > interp) return 0;
    vector<Vector> vertices;

    LERP lerp;
    lerp.Init(points[0], points[1]);
    lerp.Calc(t_scale, vertices);

    for(size_t k = 0; k < vertices.size(); k++)
      {
        float t = (float)k / (float)t_scale;
        const Vector &v = vertices[k];

        int frame = t * t_scale + points[0].frame;
        if(out.size() && out.back().frame == frame) continue;

        out.push_back(::Marker(front.id, frame, v.x, v.y, v.z, 4.4, 0x10));
      }

    return 1;
  }

  int doQuadratic(const vector<OWLMarker> &points, vector<OWLMarker> &out, const OWLMarker &front)
  {
    if(points.size() < 3 ||
       !(points[0].id == points[1].id && points[0].id == points[2].id) ||
       points[0].frame == points[1].frame) return 0;

    float t_scale = points[2].frame - points[0].frame;

    vector<Vector> vertices(t_scale);

    QuadraticFit quad;
    if(!quad.Init(points)) return 0;
    if(!quad.Calc(t_scale, vertices)) return 0;

    size_t mid = points[1].frame - points[0].frame;
    size_t k = 0; // right-slope -- i.e. push new from start to mid
    size_t stop = mid + 1; // left-slope -- i.e. keep from mid to end

    // test if using left slope
    if(points[0].frame < front.frame)
      {
        k = mid;
        stop = vertices.size();
      }

    for(; k < stop; k++)
      {
        float t = (float)k / (float)t_scale;
        const Vector &v = vertices[k];

        int frame = t * t_scale + points[0].frame;
        if(out.size() && out.back().frame == frame) continue;

        out.push_back(::Marker(front.id, frame, v.x, v.y, v.z, 4.3, 0x10));
      }

    return 1;
  }

  int doCubic(const vector<OWLMarker> &points, vector<OWLMarker> &out, const OWLMarker &front)
  {
    if(points[0].frame >= front.frame) return 0; // we need the past frame otherwise quit
    if(points.size() < 4) return 0;

    // get slopes
    vector<OWLMarker> fd;
    fd.resize(fd.size()+1);
    if(!getSlopes(points, fd)) return 0;

    HermiteSpline<Vector> hs;
    float s = points[2].frame - points[1].frame;
    hs.Init(points[1], points[2], fd[1], fd[2], s); // using slope from finite diffs

    vector<Vector> vertices;

    float t_scale = points[2].frame - points[1].frame;
    int LOD = t_scale;

    hs.Calc(LOD, vertices);
    for(size_t k = 0; k < vertices.size(); k++)
      {
        float t = (float)k / (float)LOD;
        const Vector &v = vertices[k];

        int frame = t * t_scale + points[1].frame;
        if(out.size() && out.back().frame == frame) continue;

        out.push_back(::Marker(front.id, frame, v.x, v.y, v.z, 4.2, 0x10));
      }

    return 1;
  }

  void applyPoints(const vector<OWLMarker> &src_markers, int idx)
  {
    if(!src_markers.size()) return;
    vector<OWLMarker>::const_iterator src_marker = src_markers.begin();
    deque< vector<OWLMarker> >::iterator frame = markers.begin();

    for(; frame != markers.end() && src_marker != src_markers.end(); frame++)
      {
        if(idx >= (int)(*frame).size()) continue;

        if((*frame)[idx].frame < src_marker->frame) continue;

        if((*frame)[idx].frame == src_marker->frame)
          {
            // if real && visible, ignore
            if(!((*frame)[idx].flag & 0x10) && (*frame)[idx].cond > 0)
              {
                src_marker++;
                continue;
              }

            int flag = (*frame)[idx].flag | 0x10;
            (*frame)[idx] = *src_marker;
            (*frame)[idx].flag = flag;
            src_marker++;
          }
      }
  }
};

//// _OWLClient ////

class _OWLClient {
public:

  enum { MAX_DATA_SIZE = 1024*1024, BUF_SIZE = 0x1000000 };

  int sock;
  int broadcast;

  struct sockaddr_in addr;

  _OWLHeader *in_header;
  _OWLHeader *out_header;

  std::buffer<char> in_buffer;

  _OWLClient() : sock(-1), in_buffer(BUF_SIZE)
  {
    in_header = (_OWLHeader*)new char[MAX_DATA_SIZE];
    out_header = (_OWLHeader*)new char[MAX_DATA_SIZE];

#ifdef WIN32
    winsock_init();
#endif
  }

  ~_OWLClient()
  {
    delete[] in_header;
    delete[] out_header;
#ifdef WIN32
    winsock_cleanup();
#endif
  }

  _OWLHeader *Out(packet_t type, int size, int frame)
  {
    assert(size + sizeof(_OWLHeader) < MAX_DATA_SIZE);
    out_header->type = type;
    out_header->size = size;
    out_header->frame = frame;//_owl.frameNumber;

    return out_header;
  }

  void Close()
  {
    if(sock == -1) return;
    cout << "closing socket: " << sock << endl;
    closesocket(sock);
    sock = -1;
    in_buffer.clear();
  }

  void Send(int retry=1000)
  {
    if(sock == -1) return;
    int ret = 0;

    if(out_header->size == 0) { cerr << "header->size == 0" << endl; return; }

    do {
      ret = tcp_send(sock, (char*)out_header, sizeof(_OWLHeader) + out_header->size);
      if(ret) break;
      delay(1);
    } while(--retry > 0);

    if(ret != (int)(out_header->size+sizeof(_OWLHeader)))
      {
	cerr << "send(" << (int)(out_header->size+sizeof(_OWLHeader)) << ") failed." << endl;
      }

    assert(ret == (int)(out_header->size+sizeof(_OWLHeader)));
  }

  // new networking code (buffered)
  int Recv(OWLContext *ctx);

};

//// OWLContext ////

struct OWLContext {

  OWLContext *self;

  _OWLState owl;
  _OWLClient client;
  _OWLClient broadcast;
  _RPDClient rpd_client;

  OWLContext() : self(this), rpd_client(0x1000000, 0x100000) { }

  int owl_done(int ret=0);
  int owl_read();
  int owl_parse(_OWLHeader *p);
  void set_transform(const float *p, int n);

  bool buffer_sizes();

  int add_c3dmarkers();
  int add_event(int type, int frame);
  int add_markers(_OWLHeader *p);
  int add_rigids(_OWLHeader *p);
  int add_cameras(_OWLHeader *p);
  int add_config(_OWLHeader *p);
  int add_floats(_OWLHeader *p);
  int add_integers(_OWLHeader *p);
  int add_string(_OWLHeader *p);
  int add_peaks(_OWLHeader *p);
  int add_detectors(_OWLHeader *p);
  int add_planes(_OWLHeader *p);

  template <class T>
  void add_param(deque<T> &l, OWLenum pname, const void *param, size_t count, int reuse);

  void add_float(OWLenum pname,  const float *param, size_t count, int reuse=0);
  void add_integer(OWLenum pname, const int *param, size_t count, int reuse=0);
  void add_string(OWLenum pname, const char *param, size_t count, int reuse=0);

  void send_init(int flags);
  void send_request(size_t type);
  void owl_send_data(packet_t type, OWLenum pname, const void *data, size_t bytes);
  void owl_send_data(packet_t type, int number, OWLenum pname, const void *data, size_t bytes);
};

//// globals ////

//_OWLState _owl;
//_OWLClient _client;
//_OWLClient _broadcast;

OWLAPI size_t _tcp_sndbuf_size = 0x400000;
OWLAPI size_t _tcp_rcvbuf_size = 0x400000;
OWLAPI size_t _rpd_chunk_size = 0x10000;
OWLAPI size_t _tcp_connect_timeout = 5000000;

#define INT(data) ((int*)(data))
#define FLOAT(data) ((float*)(data))
#define ENUM(data) ((OWLenum*)(data))

void owlDone(OWLContext *ctx);

//// owl context ////

OWLContext* owlCreateContext()
{
  return new OWLContext;
}

void owlReleaseContext(OWLContext **ctx)
{
  if(!ctx || !*ctx) return;

  delete *ctx;

  *ctx = 0;
}

//// _OWLClient ////

// new networking code (buffered)
int _OWLClient::Recv(OWLContext *ctx)
{
  int ret = 0;

  if(broadcast && sock > -1)
    {
      ret = udp_recv(sock, &addr, in_buffer.end(), in_buffer.available());
      //if(ret) cout << "udp_recv=" << ret << " of " << in_buffer.available() << endl;
      if(ret < 0) Close();
      if(ret > 0) in_buffer += ret;        
    }
  else if(sock > -1)
    {
      ret = tcp_recv(sock, in_buffer.end(), in_buffer.available());
      //if(ret) cout << "owl_recv=" << ret << " of " << in_buffer.available() << endl;
      if(ret < 0)
        {
          // don't try to recover data left in buffer(s), too much effort
          return ctx->owl_done(ret);
        }
      if(ret > 0) in_buffer += ret;
    }
  else if(in_buffer.size() == 0)
    {
      return -1;
    }

  if(in_buffer.size() <= sizeof(_OWLHeader)) return 0;

  _OWLHeader *h = (_OWLHeader*)in_buffer.begin();

  assert(h->size >= 0);

  size_t count = sizeof(_OWLHeader) + h->size;

  if(count > in_buffer.size()) return 0;

  memcpy((char*)in_header, (char*)h, count);

  in_buffer -= count;

  return in_header->size;
}

//// OWLContext ////

// ret is passthrough
int OWLContext::owl_done(int ret)
{
  if(owl.init == 0x10) cout << "owl done" << endl;
  owl.init = 0;

  client.Close();
  broadcast.Close();

  return ret;
}

// main packet handler
// return value:
//  success: 0
//  error:   <0 (-errno)
int OWLContext::owl_read()
{
  int ret;

  // delay exiting
  if(owl.exiting)
    {
      if(owl.IsEmpty())
	{
	  owl.errors.push_back(0x1); // ERROR
          add_event(OWL_DONE, owl.frameNumber);
          add_string(OWL_STATUS_STRING, "disconnected", 0);

	  owl_done();
	}
      return -1;
    }

  // file reading
  if(owl.flags & OWL_FILE)
    {
      ret = 0;

      while(owl.recState.frameAvailable())
        {
          ret = add_c3dmarkers();

          if(ret < 0)
            {
              owl.exiting = 1;
              break;
            }

          owl.recState.index++;
        }

      return ret < 0 ? ret : 0;
    }

  // socket reading
  int count = 0;
  do {
    count = 0;

    // read client
    ret = client.Recv(this);

    //if(ret != 0) cout << "read: " << ret << endl;

    if(ret < 0)
      {
        // errno does not (always?) get set on recv()==0
        owl.errors.push_back(0x1); // errno ERROR
        return ret;
      }

    if(ret > 0)
      {
        count += ret;
        if(owl_parse(client.in_header) < 0) break;
      }

    // read broadcast
    if(broadcast.sock > -1 && broadcast.broadcast)
      {
        ret = broadcast.Recv(this);

        //if(ret != 0) cout << "read: " << ret << endl;

        if(ret < 0) return ret;

        if(ret > 0)
          {
            count += ret;
            if(owl_parse(broadcast.in_header) < 0) break;
          }
      }
	 
  } while(count);

  if(ret < 0) owl.errors.push_back(ret);
  
  return ret < 0 ? ret : 0;
}

int OWLContext::owl_parse(_OWLHeader *p)
{
  int ret = 0;

  if(!buffer_sizes()) return 0;

  if(p->type > pNone && p->type < pLast)
    {
      if(p->frame > owl.frameNumber)
        {
          owl.frameNumber = p->frame;
          if(add_event(OWL_FRAME_NUMBER, p->frame) < 0)
            return 0;
        }
    }
  else
    {
      cerr << "error: owl_read: unknown packet type: " << p->type << endl;
      return 0;
    }

  if(p->type == pInit)
    {
      DBG(cout << "pInit" << endl);
      int flags = *INT(p->data+0);
      size_t version = *ENUM(p->data+4);

      assert(owl.init == 3);

      cout << "server version: " 
           << ((version&0xFF0000)>>16) << "." 
           << ((version&0x00FF00)>>8) << "."
           << ((version&0x0000FF)>>0) << endl;
	  
      size_t rversion = OWL_PROTOCOL_VERSION;
      if(version != rversion)
        {
          cerr << "warning: server version does not match client version: "
               << ((rversion&0xFF0000)>>16) << "." 
               << ((rversion&0x00FF00)>>8) << "."
               << ((rversion&0x0000FF)>>0) << endl;
        }

      if(owl.flags & OWL_SLAVE)
        {
          owl.flags = flags | OWL_SLAVE;
        }
      else if(owl.flags != flags)
        {
          owl.errors.push_back(OWL_INVALID_VALUE);

          owlDone(this);
          return -1;
        }
      owl.init = 0x10;
    }
  else if(p->type == pDone)
    {
      DBG(cout << "pDone" << endl);
	  
      owl.exiting = 1;

      return -1;
    }
  else if(p->type == pError)
    {
      int error = *INT(p->data+0);
      DBG(cout << "pError: " << hex << error << dec << endl);

      owl.errors.push_back(error);
    }
  else if(p->type == pMarkers)
    {
      DBG(cout << "pMarkers: " << p->size/sizeof(_OWLMarkerData) << endl);
      ret = add_markers(p);
      if(ret > 0) add_event(OWL_MARKERS, p->frame);
    }
  else if(p->type == pRigids)
    {
      DBG(cout << "pRigids: " << p->size/sizeof(_OWLRigidData) << endl);
      ret = add_rigids(p);
      if(ret > 0) add_event(OWL_RIGIDS, p->frame);
    }
  else if(p->type == pCameras)
    {
      DBG(cout << "pCameras: " << p->size/sizeof(_OWLCameraData) << endl);
      ret = add_cameras(p);
      if(ret > 0) add_event(OWL_CAMERAS, p->frame);
    }
  else if(p->type == pConfig)
    {
      DBG(cout << "pConfig: " << p->size/sizeof(_OWLConfigData) << endl);
      ret = add_config(p);
    }
  else if(p->type == pFloatv)
    {
      DBG(cout << "pFloatv: " << p->size/4 << endl);
      ret = add_floats(p);
    }
  else if(p->type == pIntegerv)
    {
      DBG(cout << "pIntegerv: " << p->size/4 << endl);
      ret = add_integers(p);
    }
  else if(p->type == pString)
    {
      DBG(cout << "pString: " << p->size << endl);
      ret = add_string(p);
    }
  else if(p->type == pAck)
    {
      DBG(cout << "pAck: 0x" << hex << *ENUM(p->data+0) << dec << endl);
      owl.lastAck = *ENUM(p->data+0);
      // do nothing
    }
  else if(p->type == pPeaks)
    {
      DBG(cout << "pPeaks: " << p->size/sizeof(_OWLPeakData) << endl);
      ret = add_peaks(p);
      if(ret > 0) add_event(OWL_PEAKS, p->frame);
    }
  else if(p->type == pDetectors)
    {
      DBG(cout << "pDetectors: " << p->size/sizeof(_OWLDetectorsData) << endl);
      ret = add_detectors(p);
      if(ret > 0) add_event(OWL_DETECTORS, p->frame);
    }
  else if(p->type == pPlanes)
    {
      DBG(cout << "pPlanes: " << p->size/sizeof(_OWLPlaneData) << endl);
      ret = add_planes(p);
      if(ret > 0) add_event(OWL_PLANES, p->frame);
    }
  else
    {
      cerr << "error: owl_read: unhandled packet type: 0x" 
           << hex << p->type << dec << endl;
    }

  return ret;
}

template <int N, class A, class B>
void copy_v(const A *a, B *b)
{
  for(int i = 0; i < N; i++) b[i] = a[i];
}

void copy_marker(OWLMarker &m, const _OWLMarkerData &d, int frame)
{
  m.id = d.id;
  m.frame = frame;
  m.x = d.pos[0];
  m.y = d.pos[1];
  m.z = d.pos[2];
  m.cond = d.cond;
  m.flag = d.flag;
}

void copy_rigid(OWLRigid &r, const _OWLRigidData &d, int frame)
{
  r.id = d.id;
  r.frame = frame;
  copy_v<7>(d.pose, r.pose);
  r.cond = d.cond;
  r.flag = d.flag;
}

void copy_camera(OWLCamera &c, const _OWLCameraData &d)
{
  c.id = d.id;
  copy_v<7>(d.pose, c.pose);
  c.cond = d.cond;
  c.flag = d.flag;
}

void copy_peaks(OWLPeak &p, const _OWLPeakData &d, int frame)
{
  p.id = d.id;
  p.frame = frame;
  p.camera = d.camera;
  p.detector = d.detector;
  p.width = d.width;
  p.flag = d.flag;
  
  p.pos = d.pos;
  p.amp = d.amp;
}

void copy_detectors(OWLDetectors &det, const _OWLDetectorsData &d, int frame)
{
  assert(sizeof(d.detectors) == sizeof(uint_t)*8);
  det.id = d.id;
  det.frame = frame;
  for(int i = 0; i < 8; i++)
    det.detectors[i] = d.detectors[i];
}

void copy_plane(OWLPlane &p, const _OWLPlaneData &d, int frame)
{
  p.id = d.id;
  p.camera = d.camera;
  p.frame = frame;
  p.plane[0] = d.plane[0];
  p.plane[1] = d.plane[1];
  p.plane[2] = d.plane[2];
  p.plane[3] = d.plane[3];
  p.cond = d.cond;
  p.flag = d.flag;
}

// 0: server transform
// 1: client transform
void OWLContext::set_transform(const float *p, int n)
{
  if(p && n > -1 && n < 2) copy_v<7>(p, owl.p_stack[n]);

  // scale server transform
  float p0[7]; copy_v<7>(owl.p_stack[0], p0);
  for(size_t i = 0; i < 3; i++) p0[i] *= owl.scale;

  mult_pp(owl.p_stack[1], p0, owl.pose);

  convert_pm(owl.pose, owl.m);
  convert_pmi(owl.pose, owl.m_1);
}

bool OWLContext::buffer_sizes()
{
  if(owl.frameBufferSize <= 0) return 1;

  if(owl.enableEvents && (int)owl.events.size() > owl.frameBufferSize*10)
    {
      //cerr << "error: owl_read: event storage exceeded" << endl;
      return 0;
    }

  if((int)owl.markers.size() > owl.frameBufferSize)
    {
      //cerr << "error: owl_read: marker storage exceeded" << endl;
      return 0;
    }

  if((int)owl.rigids.size() > owl.frameBufferSize)
    {
      //cerr << "error: owl_read: rigid storage exceeded" << endl;
      return 0;
    }

  if((int)owl.peaks.size() > owl.frameBufferSize)
    {
      //cerr << "error: owl_read: peaks storage exceeded" << endl;
      return 0;
    }

  if((int)owl.detectors.size() > owl.frameBufferSize)
    {
      //cerr << "error: owl_read: detectors storage exceeded" << endl;
      return 0;
    }

  if((int)owl.planes.size() > owl.frameBufferSize)
    {
      //cerr << "error: owl_read: plane storage exceeded" << endl;
      return 0;
    }

  if((int)owl.floats.size() > owl.frameBufferSize)
    {
      //cerr << "error: owl_read: float storage exceeded" << endl;
      return 0;
    }

  if((int)owl.integers.size() > owl.frameBufferSize)
    {
      //cerr << "error: owl_read: integer storage exceeded" << endl;
      return 0;
    }

  if((int)owl.strings.size() > owl.frameBufferSize)
    {
      //cerr << "error: owl_read: string storage exceeded" << endl;
      return 0;
    }

  return 1;
}

int OWLContext::add_c3dmarkers()
{
  if(!owl.recState.frames.size()) return -1;

  if(owl.recState.index >= owl.recState.frames.size()) return -1;

  vector<OWLMarker> markers(owl.recState.frames[owl.recState.index]);

  try
    {
      owl.markers.push_back(markers);
    }
  catch(bad_alloc)
    {
      cerr << "error: bad_alloc: not enough memory" << endl;
      return -1;
    }

  if(markers.size()) owl.frameNumber = markers[0].frame;

  return markers.size();
}

int OWLContext::add_event(int type, int frame)
{
  if(!owl.enableEvents) return 0;
  OWLEvent e = { type, frame };
  try
    {
      owl.events.push_back(e);
    }
  catch(bad_alloc)
    {
      cerr << "error: bad_alloc: not enough memory" << endl;
      return -1;
    }
  return 1;
}

int OWLContext::add_markers(_OWLHeader *p)
{
  if(p->size <= 0) return 0;
  int n = p->size/sizeof(_OWLMarkerData);

  // handle special case for markers
  if(n == 0) return 0;

  assert(n < 1024);
  
  try
    {
      owl.markers.push_back(vector<OWLMarker>());
    }
  catch(bad_alloc)
    {
      cerr << "error: bad_alloc: not enough memory" << endl;
      return -1;
    }
  
  _OWLMarkerData *data = (_OWLMarkerData*)p->data;
  vector<OWLMarker> &markers = owl.markers.back();
  
  markers.resize(n);
  for(int i = 0; i < n; i++)
    copy_marker(markers[i], data[i], p->frame);

  owl.updateInterp(markers);

  return n;
}

int OWLContext::add_rigids(_OWLHeader *p)
{
  if(p->size <= 0) return 0;
  int n = p->size/sizeof(_OWLRigidData);

  assert(n < 1024);

  try
    {
      owl.rigids.push_back(vector<OWLRigid>());
    }
  catch(bad_alloc)
    {
      cerr << "error: bad_alloc: not enough memory" << endl;
      return -1;
    }

  _OWLRigidData *data = (_OWLRigidData*)p->data;
  vector<OWLRigid> &rigids = owl.rigids.back();

  rigids.resize(n);
  for(int i = 0; i < n; i++)
    copy_rigid(rigids[i], data[i], p->frame);

  return n;
}

int OWLContext::add_cameras(_OWLHeader *p)
{
  if(p->size <= 0) return 0;
  int n = p->size/sizeof(_OWLCameraData);
	      
  assert(n < 256);
  
  _OWLCameraData *data = (_OWLCameraData*)p->data;
  
  owl.cameras.resize(n);
  for(int i = 0; i < n; i++)
    copy_camera(owl.cameras[i], data[i]);

  return 0;
}

int OWLContext::add_peaks(_OWLHeader *p)
{
  if(p->size <= 0) return 0;
  int n = p->size/sizeof(_OWLPeakData);
  
  assert(n < 1024 * 16);

  try
    {
      owl.peaks.push_back(vector<OWLPeak>());
    }
  catch(bad_alloc)
    {
      cerr << "error: bad_alloc: not enough memory" << endl;
      return -1;
    }

  _OWLPeakData *data = (_OWLPeakData*)p->data;
  vector<OWLPeak> &peaks = owl.peaks.back();

  peaks.resize(n);
  for(int i = 0; i < n; i++)
    copy_peaks(peaks[i], data[i], p->frame);

  return n;
}

int OWLContext::add_detectors(_OWLHeader *p)
{
  if(p->size <= 0) return 0;
  int n = p->size/sizeof(_OWLDetectorsData);
  
  assert(n < 1024);

  try
    {
      owl.detectors.push_back(vector<OWLDetectors>());
    }
  catch(bad_alloc)
    {
      cerr << "error: bad_alloc: not enough memory" << endl;
      return -1;
    }

  _OWLDetectorsData *data = (_OWLDetectorsData*)p->data;
  vector<OWLDetectors> &detectors = owl.detectors.back();

  detectors.resize(n);
  for(int i = 0; i < n; i++)
    copy_detectors(detectors[i], data[i], p->frame);

  return n;
}

int OWLContext::add_planes(_OWLHeader *p)
{
  if(p->size <= 0) return 0;
  int n = p->size/sizeof(_OWLPlaneData);

  assert(n < 1024 * 16);

  try
    {
      owl.planes.push_back(vector<OWLPlane>());
    }
  catch(bad_alloc)
    {
      cerr << "error: bad_alloc: not enough memory" << endl;
      return -1;
    }

  _OWLPlaneData *data = (_OWLPlaneData*)p->data;
  vector<OWLPlane> &planes = owl.planes.back();

  planes.resize(n);
  for(int i = 0; i < n; i++)
    copy_plane(planes[i], data[i], p->frame);

  return n;
}

int OWLContext::add_config(_OWLHeader *p)
{
  if(p->size <= 0) return 0;
  int n = p->size/sizeof(_OWLConfigData);
	      
  assert(n < 256);

#if 0 
  _OWLConfigData *data = (_OWLConfigData*)p->data;

  cout << "Config: trackers=" << n << endl;
  for(int i = 0; i < n; i++)
    {
      cout << " id=" << data[i].id
	   << " type=0x" << hex << data[i].type << dec
	   << " count=" << data[i].marker_count
	   << endl;
    }
#endif

  return 0;
}

int OWLContext::add_floats(_OWLHeader *p)
{
  if(p->size < 4) return 0;
  int n = p->size;

  assert(n < 1024 * 16);
  
  OWLenum pname = *ENUM(p->data+0);
  int reuse = 0;

  if(pname == OWL_FREQUENCY)
    {
      add_event(OWL_FREQUENCY, p->frame);
      reuse = 1;
    }
  if(pname == OWL_MARKER_STATS) add_event(pname, p->frame);
  if(pname == OWL_CAMERA_STATS) add_event(pname, p->frame);
  if(pname == OWL_MARKER_COVARIANCE) add_event(pname, p->frame);
  if(pname == OWL_SYNTHETIC_2D) add_event(pname, p->frame);
  if(pname == OWL_SYNTHETIC_3D) add_event(pname, p->frame);
  if(pname == OWL_TRANSFORM)
    {
      set_transform(FLOAT(p->data+4), 0);
      add_event(OWL_CAMERAS, p->frame);
      reuse = 1;
    }
  DBG(cout << " add_float " << hex << pname << dec << " " << (p->size-4)/sizeof(float) << endl);

  add_float(pname, FLOAT(p->data+4), (p->size-4)/sizeof(float), reuse);
  
  return n;
}

int OWLContext::add_integers(_OWLHeader *p)
{
  if(p->size < 4) return 0;
  int n = p->size;

  assert(n < 1024 * 16);
  
  OWLenum pname = *ENUM(p->data+0);
  int reuse = 0;

  if(pname == OWL_STREAMING) reuse = 1;
  if(pname == OWL_BROADCAST) reuse = 1;
  if(pname == OWL_INTERPOLATION) reuse = 1;
  if(pname == OWL_BUTTONS) add_event(pname, p->frame);
  if(pname == OWL_MARKERS) reuse = 1;
  if(pname == OWL_RIGIDS) reuse = 1;
  if(pname == OWL_COMMDATA) reuse = 1;
  if(pname == OWL_TIMESTAMP) add_event(pname, p->frame);
  if(pname == OWL_PEAKS) reuse = 1;
  if(pname == OWL_DETECTORS) reuse = 1;
  if(pname == OWL_IMAGES) reuse = 1;
  if(pname == OWL_PLANES) reuse = 1;
  if(pname == OWL_MARKER_STATS);
  if(pname == OWL_CAMERA_STATS);
  if(pname == OWL_MARKER_COVARIANCE);

  DBG(cout << " add_integer " << hex << pname << dec << " " << (p->size-4)/sizeof(int) << endl);

  add_integer(pname, INT(p->data+4), (p->size-4)/sizeof(int), reuse);

  return n;
}

int OWLContext::add_string(_OWLHeader *p)
{
  if(p->size < 4) return 0;
  int n = p->size;

  assert(n < 1024 * 64);

  OWLenum pname = *ENUM(p->data+0);
  int reuse = 0;

  if(pname == OWL_COMMDATA) add_event(OWL_COMMDATA, p->frame);
  if(pname == OWL_IMAGES) add_event(OWL_IMAGES, p->frame);
  if(pname == OWL_STATUS_STRING) add_event(OWL_STATUS_STRING, p->frame);
  if(pname == OWL_CUSTOM_STRING) add_event(OWL_CUSTOM_STRING, p->frame);

  add_string(pname, (char*)p->data+4, p->size-4, reuse);

  if(pname == OWL_COMMDATA)
    owl.strings.back().data.push_back(p->frame >> 8),
      owl.strings.back().data.push_back(p->frame);

  return n;
}

/// sets

template <class T>
void OWLContext::add_param(deque<T> &l, OWLenum pname, const void *param, size_t count, int reuse)
{
  if(reuse)
    {
      typename deque<T>::iterator i = find(l.begin(), l.end(), T(pname, 0));
      if(i != l.end())
	{
	  i->data.resize(count);
	  memcpy(&*i->data.begin(), param, count * sizeof(typename T::type));
	  return;
	}
    }

  try
    {
      l.push_back(T(pname, owl.frameNumber));
    }
  catch(bad_alloc)
    {
      cerr << "error: bad_alloc: not enough memory" << endl;
      return;
    }
  
  T &n = l.back();
  n.data.resize(count);
  memcpy(&*n.data.begin(), param, count * sizeof(typename T::type));
  /// !!! use insert
}

void OWLContext::add_float(OWLenum pname, const float *param, size_t count, int reuse)
{
  add_param(owl.floats, pname, param, count, reuse);
}

void OWLContext::add_integer(OWLenum pname, const int *param, size_t count, int reuse)
{
  add_param(owl.integers, pname, param, count, reuse);
}

void OWLContext::add_string(OWLenum pname, const char *param, size_t count, int reuse)
{ 
  if(param && count == 0) count = strlen(param)+1;
  add_param(owl.strings, pname, param, count, reuse);
}

void OWLContext::send_init(int flags)
{
  _OWLHeader *p = client.Out(pInit, 8, owl.frameNumber);

  owl.flags = flags;
  *INT(p->data+0) = flags;
  *ENUM(p->data+4) = OWL_PROTOCOL_VERSION;

  client.Send();
}

void OWLContext::send_request(size_t type)
{
  _OWLHeader *p = client.Out(pRequest, 4, owl.frameNumber);
  
  *ENUM(p->data+0) = type;
  
  client.Send();
}

void OWLContext::owl_send_data(packet_t type, OWLenum pname, const void *data, size_t bytes)
{
  _OWLHeader *p = client.Out(type, 4+bytes, owl.frameNumber);
  
  *ENUM(p->data+0) = pname;
  if(bytes && data) memcpy(p->data+4, data, bytes);
  
  client.Send();
}

void OWLContext::owl_send_data(packet_t type, int number, OWLenum pname, const void *data, size_t bytes)
{
  _OWLHeader *p = client.Out(type, 8+bytes, owl.frameNumber);

  *INT(p->data+0) = number;
  *ENUM(p->data+4) = pname;
  if(bytes && data) memcpy(p->data+8, data, bytes);
  
  client.Send();
}

//// owl ////

int _owl_get_sock(OWLContext *ctx)
{
  CTX(ctx);

  if(!_owl) return -1;
  
  return _client.sock;
}

// return value:
//  success: flags (or flags from the server if slave)
//  waiting: 0 (with OWL_ASYNC)
//  error:   -1
int owlInit(OWLContext *ctx, const char *server, int flags)
{
  CTX(ctx);

  int async = flags & OWL_ASYNC;
  flags &= ~OWL_ASYNC;

  // re-entrant state machine based on _owl.init value
  // states can cascade into next within same call
  // won't block on OWL_ASYNC

  // already connected
  if(_owl.init == 0x10)
    {
      if(_owl.server == server) return _owl.flags | async;
      else
        {
          // already in use
          _owl.errors.push_back(OWL_INVALID_OPERATION);
          return -1;
        }
    }

  // separate server name into name:port
  char name[1024] = "localhost";
  int port = 0;

  if(server)
    {
      const char *ptr = strchr(server, ':');
      int size = ptr ? ptr - server : strlen(server);
      
      if(size) memcpy(name, server, size), name[size] = 0; 
      if(ptr) sscanf(ptr, ":%d", &port);
    }

  // initial connect
  if(_owl.init == 0)
    {
      _owl.InitClientState();

      _owl.server = server;
  
      float f = 0;
      ctx->add_float(OWL_FREQUENCY, &f, 1, 1);

      int n = OWL_DISABLE;
      ctx->add_integer(OWL_STREAMING, &n, 1, 1);
      ctx->add_integer(OWL_BROADCAST, &n, 1, 1);

      n = 0;
      ctx->add_integer(OWL_INTERPOLATION, &n, 1, 1);

      n = OWL_ENABLE;
      ctx->add_integer(OWL_MARKERS, &n, 1, 1);
      ctx->add_integer(OWL_RIGIDS, &n, 1, 1);
      ctx->add_integer(OWL_PEAKS, &n, 1, 1);
      ctx->add_integer(OWL_DETECTORS, &n, 1, 1);
      ctx->add_integer(OWL_IMAGES, &n, 1, 1);
      ctx->add_integer(OWL_PLANES, &n, 1, 1);
      ctx->add_integer(OWL_COMMDATA, &n, 1, 1);

      // owl file reading mode
      if(flags & OWL_FILE)
        {
          int ret = _owl.recState.Init(server);
          if(ret > 0)
            {
              _owl.init = 0x10;
              _owl.flags = flags;

              return _owl.flags;
            }
          else
            return ret;
        }
  
      _client.sock = connect_tcp(name, 8000+port, async ? 0 : _tcp_connect_timeout);
      if(_client.sock == -1)
        {
          // can't connect to server
          _owl.errors.push_back(-get_net_error());
          return -1;
        }

      _owl.init = async ? 1 : 2;
      _owl.connectTime = timer.get();
    }

  // should have socket at this point
  if(_client.sock == -1)
    {
      _owl.init = 0;
      return -1;
    }

  // waiting for connected
  if(_owl.init == 1)
    {
      int ret = connected(_client.sock, 0);
      if(ret > 0)
        {
          _owl.init = 2;
        }
      else if(ret < 0)
        {
#ifndef WIN32
          cerr << "owl connect: " << strerror(errno) << endl;
#else
          cerr << "owl connect: error=" << WSAGetLastError() << endl;
#endif
          // can't connect to server
          _owl.errors.push_back(-get_net_error());
          return ctx->owl_done(-1);
        }
      else if(_tcp_connect_timeout && timer.get() - _owl.connectTime > _tcp_connect_timeout)
        {
          set_net_error(NET_ERROR(ETIMEDOUT, WSAETIMEDOUT));
#ifndef WIN32
          cerr << "owl connect: " << strerror(errno) << endl;
#else
          cerr << "owl connect: error=" << WSAGetLastError() << endl;
#endif
          // can't connect to server
          _owl.errors.push_back(-get_net_error());
          return ctx->owl_done(-1);
        }
      else return 0; // come back later
    }

  // connected: initialize client
  if(_owl.init == 2)
    {
      DBG(cout << "owl connect: " << _client.sock << endl);
      nonblock(_client.sock);
      set_sndbuf(_client.sock, _tcp_sndbuf_size);
      set_rcvbuf(_client.sock, _tcp_rcvbuf_size);
      //cout << "SNDBUF=" << get_sndbuf(_client.sock) << endl;
      //cout << "RCVBUF=" << get_rcvbuf(_client.sock) << endl;

      ctx->send_init(flags);

      _owl.init = 3;
    }

  // waiting for init
  if(_owl.init == 3)
    {
      int c = 1;
      while(_owl.init != 0x10)
        {
          int ret = ctx->owl_read();
          if(_owl.init == 0x10) break;

          if(ret < 0) return ctx->owl_done(-1);

          if(_owl.errors.size() > 0) return ctx->owl_done(-1);

          if(async)
            {
              if(_tcp_connect_timeout && timer.get() - _owl.connectTime > _tcp_connect_timeout * 2)
                {
                  cout << "owl connect timed out" << endl;
                  return ctx->owl_done(-1);
                }
              return 0; // come back later
            }

          delay(1);

          if(c++ > 30000) return ctx->owl_done(-2);
        }

      // broadcast listener socket
      {
        _broadcast.sock = listen_udp(8500+port);
        if(_broadcast.sock < 0)
          {
#ifndef WIN32
            cerr << "error: setup_listening(SOCK_DGRAM): " << strerror(errno) << endl;
#else
            cerr << "error: setup_listening(SOCK_DGRAM): error=" << WSAGetLastError() << endl;
#endif
          }
        else
          {
            nonblock(_broadcast.sock);
            set_rcvbuf(_broadcast.sock, _tcp_rcvbuf_size);
            DBG(cout << "broadcast listener: " << _broadcast.sock << endl);
          }
      }

      //cout << "owlInit done" << endl;

      return _owl.flags | async;
    }

  cout << "invalid owl init state: " << _owl.init << endl;

  return ctx->owl_done(-1);
}

void owlDone(OWLContext *ctx)
{
  CTX(ctx);

  // slave does not send out pDone packet
  if(_owl && (_owl.flags & OWL_SLAVE) == 0)
    {
      //cout << "done" << endl;
      _OWLHeader *p = _client.Out(pDone, 4, _owl.frameNumber);
      *INT(p->data+0) = 0;
      
      _client.Send();
      
      // wait for server to get the command
      delay(10);
    }

  ctx->owl_done();

  //cout << "owlDone" << endl;
}

/* Sets */

void owlSetFloat(OWLContext *ctx, OWLenum pname, float param)
{
  CTX(ctx);

  if(!_owl) { _owl.errors.push_back(OWL_INVALID_OPERATION); return; }

  ctx->owl_send_data(pSetFloatv, pname, &param, 4);
}

void owlSetInteger(OWLContext *ctx, OWLenum pname, int param)
{
  CTX(ctx);

  if(!_owl) { _owl.errors.push_back(OWL_INVALID_OPERATION); return; }

  if(pname == OWL_EVENTS)
    {
      _owl.enableEvents = (param == OWL_ENABLE);
      return;
    }

  if(pname == OWL_INTERPOLATION)
    {
      _owl.interp = param;
      return;
    }

  if(pname == OWL_FRAME_BUFFER_SIZE)
    {
      _owl.frameBufferSize = param;
      return;
    }

  ctx->owl_send_data(pSetIntegerv, pname, &param, 4);

  if(pname == OWL_BROADCAST)
    {
      _broadcast.broadcast = (param == OWL_ENABLE);
    }
}

void owlSetFloatv(OWLContext *ctx, OWLenum pname, const float *param)
{
  CTX(ctx);

  if(!_owl) { _owl.errors.push_back(OWL_INVALID_OPERATION); return; }

  if(pname == OWL_SYNTHETIC_2D)
    {
      ctx->owl_send_data(pSetFloatv, pname, param, 3*4);
    }
  else if(pname == OWL_SYNTHETIC_3D)
    {
      float p[3];
      mult_mv3_v3(_owl.m_1, param, p);
      p[0] /= _owl.scale;
      p[1] /= _owl.scale;
      p[2] /= _owl.scale;
      ctx->owl_send_data(pSetFloatv, pname, p, 3*4);
    }
  else if(pname == OWL_TRANSFORM)
    {
      ctx->owl_send_data(pSetFloatv, pname, param, 7*4);
      ctx->send_request(OWL_REQUEST_CAMERAS);
    }
  else
    ctx->owl_send_data(pSetFloatv, pname, param, 4);
}

void owlSetIntegerv(OWLContext *ctx, OWLenum pname, const int *param)
{
  CTX(ctx);

  if(!_owl) { _owl.errors.push_back(OWL_INVALID_OPERATION); return; }

  if(pname == OWL_EVENTS)
    {
      _owl.enableEvents = (*param == OWL_ENABLE);
      return;
    }

  if(pname == OWL_FRAME_BUFFER_SIZE)
    {
      _owl.frameBufferSize = *param;
      return;
    }

  if(pname == OWL_CAMERAS)
    {
      ctx->owl_send_data(pSetIntegerv, pname, param, 4 * _owl.cameras.size());
      return;
    }

  ctx->owl_send_data(pSetIntegerv, pname, param, 4);

  if(pname == OWL_BROADCAST)
    {
      _broadcast.broadcast = (*param == OWL_ENABLE);
    }
}

void owlSetString(OWLContext *ctx, OWLenum pname, const char *str)
{
  CTX(ctx);

  if(!_owl) { _owl.errors.push_back(OWL_INVALID_OPERATION); return; }

  ctx->owl_send_data(pSetString, pname, str, strlen(str)+1);
}

/* Tracker */

void owlTracker(OWLContext *ctx, int tracker, OWLenum pname)
{
  CTX(ctx);

  if(!_owl) { _owl.errors.push_back(OWL_INVALID_OPERATION); return; }

  ctx->owl_send_data(pTracker, tracker, pname, 0, 0);
}

void owlTrackerf(OWLContext *ctx, int tracker, OWLenum pname, float param)
{
  CTX(ctx);

  if(!_owl) { _owl.errors.push_back(OWL_INVALID_OPERATION); return; }

  ctx->owl_send_data(pTrackerfv, tracker, pname, &param, 4);
}

void owlTrackeri(OWLContext *ctx, int tracker, OWLenum pname, int param)
{
  CTX(ctx);

  if(!_owl) { _owl.errors.push_back(OWL_INVALID_OPERATION); return; }
  
  ctx->owl_send_data(pTrackeriv, tracker, pname, &param, 4);
}

void owlTrackerfv(OWLContext *ctx, int tracker, OWLenum pname, const float *param)
{
  CTX(ctx);

  if(!_owl) { _owl.errors.push_back(OWL_INVALID_OPERATION); return; }
  
  if(pname == OWL_SET_FILTER)
    ctx->owl_send_data(pTrackerfv, tracker, pname, param, 4*4);
  else
    ctx->owl_send_data(pTrackerfv, tracker, pname, param, 4);
}

void owlTrackeriv(OWLContext *ctx, int tracker, OWLenum pname, const int *param)
{
  CTX(ctx);

  if(!_owl) { _owl.errors.push_back(OWL_INVALID_OPERATION); return; }

  if(pname == OWL_RECALIBRATE && param)
    {
      int n = 4;
      for(size_t i = 1; param[i] > -1 && i < _owl.cameras.size()+1; i++, n+=4)
        if(n > 4) ctx->owl_send_data(pTrackeriv, tracker, pname, param, n+4);
    }
  else
    ctx->owl_send_data(pTrackeriv, tracker, pname, param, 4);
}


/* Marker */

void owlMarker(OWLContext *ctx, int marker, OWLenum pname)
{
  CTX(ctx);

  if(!_owl) { _owl.errors.push_back(OWL_INVALID_OPERATION); return; }

  ctx->owl_send_data(pMarker, marker, pname, 0, 0);
}

void owlMarkerf(OWLContext *ctx, int marker, OWLenum pname, float param)
{
  CTX(ctx);

  if(!_owl) { _owl.errors.push_back(OWL_INVALID_OPERATION); return; }

  ctx->owl_send_data(pMarkerfv, marker, pname, &param, 4);
}

void owlMarkeri(OWLContext *ctx, int marker, OWLenum pname, int param)
{
  CTX(ctx);

  if(!_owl) { _owl.errors.push_back(OWL_INVALID_OPERATION); return; }

  ctx->owl_send_data(pMarkeriv, marker, pname, &param, 4);
}

void owlMarkerfv(OWLContext *ctx, int marker, OWLenum pname, const float *param)
{
  CTX(ctx);

  if(!_owl) { _owl.errors.push_back(OWL_INVALID_OPERATION); return; }

  if(pname == OWL_SET_POSITION)
    {
      float pos[3];
      for(int i = 0; i < 3; i++) pos[i] = param[i] * _owl.scale;

      ctx->owl_send_data(pMarkerfv, marker, pname, pos, 12);
    }
  else
    ctx->owl_send_data(pMarkerfv, marker, pname, param, 4);
}

void owlMarkeriv(OWLContext *ctx, int marker, OWLenum pname, const int *param)
{
  CTX(ctx);

  if(!_owl) { _owl.errors.push_back(OWL_INVALID_OPERATION); return; }

  ctx->owl_send_data(pMarkeriv, marker, pname, param, 4);
}


/// client ///
void owlScale(OWLContext *ctx, float scale)
{
  CTX(ctx);

  if(!_owl) { _owl.errors.push_back(OWL_INVALID_OPERATION); return; }
  _owl.scale = scale;
  ctx->set_transform(0, -1);
}

// pose: pos, rot -- [x y z], [s x y z]
void owlLoadPose(OWLContext *ctx, const float *pose)
{
  CTX(ctx);

  if(!_owl) { _owl.errors.push_back(OWL_INVALID_OPERATION); return; }

  ctx->set_transform(pose, 1);
}


/// server -> client ///

int owlGetStatus(OWLContext *ctx)
{
  CTX(ctx);

  if(!_owl) return -1;

  if(_owl.flags & OWL_FILE) return 1;

  _owl.lastAck = 0;
  ctx->send_request(OWL_REQUEST_ACK);
 
  int ret = 0;
  while(_owl.lastAck != pRequest)
    {
      ret = ctx->owl_read();

      if(ret < 0) return 0;

      if(_owl.errors.size() > 0) return 0;

      delay(1);
    }

  return _owl.errors.size() == 0;
}

int owlGetError(OWLContext *ctx)
{
  CTX(ctx);

  if(_owl) ctx->owl_read();

  if(_owl.errors.size())
    {
      int e = _owl.errors.front();
      _owl.errors.pop_front();
      return e;
    }
  
  return OWL_NO_ERROR;
}

OWLEvent owlPeekEvent(OWLContext *ctx)
{
  CTX(ctx);

  if(_owl) ctx->owl_read();

  OWLEvent e = {0, 0};
  if(_owl.events.size())
    {
      if(!_owl.interp || _owl.exiting || (_owl.events.front().frame < (_owl.frameNumber - _owl.interp)))
        return _owl.events.front();
    }
  return e;
}

OWLEvent owlGetEvent(OWLContext *ctx)
{
  CTX(ctx);

  if(_owl) ctx->owl_read();

  OWLEvent e = {0, 0};
  if(_owl.events.size())
    {
      if(!_owl.interp || _owl.exiting || (_owl.events.front().frame < (_owl.frameNumber - _owl.interp)))
        {
          e = _owl.events.front();
          _owl.events.pop_front();
        }
    }
  return e;
}

// return values for all owlGet functions:
//   success:  number of elements (zero indicates absence of data)
//   error:   <0 (-errno)
int owlGetMarkers(OWLContext *ctx, OWLMarker *markers, uint_t count)
{
  CTX(ctx);

  if(!_owl) { _owl.errors.push_back(OWL_INVALID_OPERATION); return -1; }

  ctx->owl_read();
  
  size_t n = 0;

  if(_owl.dataReady(_owl.markers))
    {
      vector<OWLMarker> &m = _owl.markers.front();

      n = m.size();
      
      if(n > count) n = count;
      
      for(size_t i = 0; i < n; i++)
	{
	  markers[i] = m[i];
	  
	  if(markers[i].cond > 0)
	    {
	      // scale
	      m[i].x *= _owl.scale;
	      m[i].y *= _owl.scale;
	      m[i].z *= _owl.scale;
	      
	      // transform
	      mult_mv3_v3(_owl.m, &m[i].x, &markers[i].x);
	    }
	}
      
      _owl.markers.pop_front();
    }
  
  return n;
}

int owlGetRigids(OWLContext *ctx, OWLRigid *rigid, uint_t count)
{
  CTX(ctx);

  if(!_owl) { _owl.errors.push_back(OWL_INVALID_OPERATION); return -1; }

  ctx->owl_read();

  size_t n = 0;

  if(_owl.dataReady(_owl.rigids))
    {
      vector<OWLRigid> &r = _owl.rigids.front();
      
      n = r.size();

      if(n > count) n = count;

      for(size_t i = 0; i < n; i++)
	{
	  rigid[i] = r[i];

	  if(rigid[i].cond > 0)
	    {
	      // scale and apply pose
	      rigid[i].pose[0] *= _owl.scale;
	      rigid[i].pose[1] *= _owl.scale;
	      rigid[i].pose[2] *= _owl.scale;
	      
	      float p[7];  copy_v<7>(rigid[i].pose, p);
	      
	      mult_pp(_owl.pose, p, rigid[i].pose);
	    }
	}

      _owl.rigids.pop_front();
    }

  return n;
}

// this is the old form of get rigids, for backwards compatibility
#undef owlGetRigid
extern "C"
int owlGetRigid(OWLContext *ctx, OWLRigid *rigid, uint_t count)
{
  return owlGetRigids(ctx, rigid, count);
}

int owlGetCameras(OWLContext *ctx, OWLCamera *cameras, uint_t count)
{
  CTX(ctx);

  if(!_owl) { _owl.errors.push_back(OWL_INVALID_OPERATION); return -1; }

  ctx->owl_read();

  size_t n = 0;
  
  for(n = 0; n < _owl.cameras.size() && n < count; n++)
    {
      cameras[n] = _owl.cameras[n];

      if(cameras[n].cond > 0)
	{
	  // scale and apply pose
	  cameras[n].pose[0] *= _owl.scale;
	  cameras[n].pose[1] *= _owl.scale;
	  cameras[n].pose[2] *= _owl.scale;
	  
	  float p[7];  copy_v<7>(cameras[n].pose, p);
	  
	  mult_pp(_owl.pose, p, cameras[n].pose);
	}
    }

  return n;
}

int owlGetPeaks(OWLContext *ctx, OWLPeak *peaks, uint_t count)
{
  CTX(ctx);

  if(!_owl) { _owl.errors.push_back(OWL_INVALID_OPERATION); return -1; }

  ctx->owl_read();

  size_t n = 0;

  if(_owl.dataReady(_owl.peaks))
    {
      vector<OWLPeak> &p = _owl.peaks.front();
      
      n = p.size();
      
      if(n > count) n = count;

      for(size_t i = 0; i < n; i++) peaks[i] = p[i];

      _owl.peaks.pop_front();
    }

  return n;
}

// stub
int owlGetImages(OWLContext *ctx, OWLImage *images, uint_t count)
{
  return owlGetPeaks(ctx, (OWLPeak*)images, count);
}

int owlGetDetectors(OWLContext *ctx, OWLDetectors *detectors, uint_t count)
{
  CTX(ctx);

  if(!_owl) { _owl.errors.push_back(OWL_INVALID_OPERATION); return -1; }

  ctx->owl_read();

  size_t n = 0;

  if(_owl.dataReady(_owl.detectors))
    {
      vector<OWLDetectors> &p = _owl.detectors.front();
      
      n = p.size();
      
      if(n > count) n = count;

      for(size_t i = 0; i < n; i++) detectors[i] = p[i];

      _owl.detectors.pop_front();
    }

  return n;
}

int owlGetPlanes(OWLContext *ctx, OWLPlane *planes, uint_t count)
{
  CTX(ctx);

  if(!_owl) { _owl.errors.push_back(OWL_INVALID_OPERATION); return -1; }

  ctx->owl_read();

  size_t n = 0;

  if(_owl.dataReady(_owl.planes))
    {
      vector<OWLPlane> &p = _owl.planes.front();
      
      n = p.size();

      if(n > count) n = count;

      for(size_t i = 0; i < n; i++)
	{
	  planes[i] = p[i];
	  
	  if(planes[i].flag > 0)
	    {
	      extern void mult_mitv_v(const float *a, const float *b, float *ab);

	      // scale
	      p[i].plane[3] *= _owl.scale;

	      /// transform
	      mult_mitv_v(_owl.m, p[i].plane, planes[i].plane);
	    }
	}
      
      _owl.planes.pop_front();
    }

  return n;
}

int owlGetFloatv(OWLContext *ctx, OWLenum pname, float *param)
{
  CTX(ctx);

  if(_owl) ctx->owl_read();

  Floats::iterator i = find(_owl.floats.begin(), _owl.floats.end(), OWLFloats(pname, 0));
  size_t n = 0;

  if(i != _owl.floats.end())
    {
      n = i->data.size();
      memcpy(param, &*i->data.begin(), n*sizeof(float));
    }

  if(pname == OWL_FREQUENCY);
  else if(pname == OWL_TRANSFORM);
  else if(pname == OWL_MARKER_STATS)
    {
      if(i != _owl.floats.end()) _owl.floats.erase(i);
    }
  else if(pname == OWL_CAMERA_STATS)
    {
      if(i != _owl.floats.end()) _owl.floats.erase(i);
    }
  else if(pname == OWL_MARKER_COVARIANCE)
    {
      void mult_mrv3_v3(const float *a, const float *b, float *ab);
      // rotate covariance matrix by transformation
      // multiply 3x1 vector at a time
      for(size_t j = 0; j < n; j += 3)
        {
          float *s = param + j;
          float p[3] = { s[0], s[1], s[2] };
          mult_mrv3_v3(_owl.m, p, s);
        }
      if(i != _owl.floats.end()) _owl.floats.erase(i);
    }
  else if(pname == OWL_SYNTHETIC_2D)
    {
      if(i != _owl.floats.end()) _owl.floats.erase(i);
    }
  else if(pname == OWL_SYNTHETIC_3D)
    {
      if(i != _owl.floats.end()) _owl.floats.erase(i);
    }
  else if(pname == OWL_CALIB_ERROR)
    {
      if(i != _owl.floats.end()) _owl.floats.erase(i);
    }
  else
    {
      assert(i == _owl.floats.end());
      _owl.errors.push_back(OWL_INVALID_ENUM);
      return -1;
    }

  return n;
}

int owlGetIntegerv(OWLContext *ctx, OWLenum pname, int *param)
{
  CTX(ctx);

  if(_owl) ctx->owl_read();

  Integers::iterator i = find(_owl.integers.begin(), _owl.integers.end(), OWLIntegers(pname, 0));
  size_t n = 0;

  if(i != _owl.integers.end())
    {
      n = i->data.size();
      memcpy(param, &*i->data.begin(), n*sizeof(int));
    }

  if(pname == OWL_STREAMING);
  else if(pname == OWL_BROADCAST);
  else if(pname == OWL_EVENTS);
  else if(pname == OWL_INTERPOLATION);
  else if(pname == OWL_MARKERS);
  else if(pname == OWL_RIGIDS);
  else if(pname == OWL_PEAKS);
  else if(pname == OWL_DETECTORS);
  else if(pname == OWL_IMAGES);
  else if(pname == OWL_PLANES);
  else if(pname == OWL_COMMDATA);
  else if(pname == OWL_FRAME_BUFFER_SIZE);
  else if(pname == OWL_BUTTONS)
    {
      if(i != _owl.integers.end()) _owl.integers.erase(i);
    }
  else if(pname == OWL_TIMESTAMP)
    {
      if(i != _owl.integers.end()) _owl.integers.erase(i);
    }
  else if(pname == OWL_FRAME_NUMBER)
    {
      *param = _owl.frameNumber;
      n = 1;
    }
  else
    {
      assert(i == _owl.integers.end());
      _owl.errors.push_back(OWL_INVALID_ENUM);
      return -1;
    }

  return n;
}

int owlGetString(OWLContext *ctx, OWLenum pname, char *str)
{
  CTX(ctx);

  if(_owl) ctx->owl_read();

  Strings::iterator i = find(_owl.strings.begin(), _owl.strings.end(), OWLString(pname, 0));
  size_t n = 0;

  if(i != _owl.strings.end())
    {
      n = i->data.size();
      if(n > 1023) n = 1023;
      memcpy(str, &*i->data.begin(), n);
      str[n] = 0;
    }

  if(pname == OWL_NO_ERROR)
    n = sprintf(str, "No Error");
  else if(pname == OWL_INVALID_VALUE)
    n = sprintf(str, "Invalid Value");
  else if(pname == OWL_INVALID_ENUM)
    n = sprintf(str, "Invalid Enum");
  else if(pname == OWL_INVALID_OPERATION)
    n = sprintf(str, "Invalid Operation");
  else if(pname == OWL_VERSION)
    {
      int v = OWL_PROTOCOL_VERSION;
      n = sprintf(str, "%d.%d.%d SOCKET", (v&0xFF0000)>>16, (v&0x00FF00)>>8, (v&0x0000FF)>>0);
    }
  else if(pname == OWL_FRAME_BUFFER_SIZE)
    {
      char tmp[1024];
      n = sprintf(str, "size=%d", _owl.frameBufferSize);
      if(_owl.enableEvents && _owl.events.size())
        {
          n += sprintf(tmp, " events=%ld", _owl.events.size());
          strcat(str, tmp);
        }
      if(_owl.markers.size())
        {
          n += sprintf(tmp, " markers=%ld", _owl.markers.size());
          strcat(str, tmp);
        }
      if(_owl.rigids.size())
        {
          n += sprintf(tmp, " rigids=%ld", _owl.rigids.size());
          strcat(str, tmp);
        }
      if(_owl.peaks.size())
        {
          n += sprintf(tmp, " peaks=%ld", _owl.peaks.size());
          strcat(str, tmp);
        }
      if(_owl.detectors.size())
        {
          n += sprintf(tmp, " detectors=%ld", _owl.detectors.size());
          strcat(str, tmp);
        }
      if(_owl.planes.size())
        {
          n += sprintf(tmp, " planes=%ld", _owl.planes.size());
          strcat(str, tmp);
        }
      if(_owl.floats.size())
        {
          n += sprintf(tmp, " floats=%ld", _owl.floats.size());
          strcat(str, tmp);
        }
      if(_owl.integers.size())
        {
          n += sprintf(tmp, " integers=%ld", _owl.integers.size());
          strcat(str, tmp);
        }
      if(_owl.strings.size())
        {
          n += sprintf(tmp, " strings=%ld", _owl.strings.size());
          strcat(str, tmp);
        }
    }
  else if(pname == OWL_COMMDATA)
    {
      if(i != _owl.strings.end()) _owl.strings.erase(i);
    }
  else if(pname == OWL_IMAGES)
    {
      if(i != _owl.strings.end()) _owl.strings.erase(i);
    }
  else if(pname == OWL_STATUS_STRING)
    {
      if(i != _owl.strings.end()) _owl.strings.erase(i);
    }
  else if(pname == OWL_CUSTOM_STRING)
    {
      if(i != _owl.strings.end()) _owl.strings.erase(i);
    }
  else if(pname == OWL_CALIB_STATUS)
    {
      if(i != _owl.strings.end()) _owl.strings.erase(i);
    }
  else
    {
      assert(i == _owl.strings.end());
      _owl.errors.push_back(OWL_INVALID_ENUM);
      return -1;
    }

  return n;
}

//// RPD /////

int owlRPDOpen(OWLContext *ctx, const char *servername, const char *filename, int mode)
{
  CTX(ctx);

  if(!servername) servername = "localhost";
  int ret = _rpd_client.Open(servername, filename, mode);
  if(ret < 0) _rpd_client.Close();
  return ret;
}

void owlRPDClose(OWLContext *ctx)
{
  CTX(ctx);

  _rpd_client.Disconnect();

  // flush
  while(_rpd_client._mode == OWL_RPD_SAVE && 
	_rpd_client.sock > -1 && 
	_rpd_client.Recv() >= 0);

  if(_rpd_client.sock > -1) _rpd_client.Close();
}

int owlRPDSend(OWLContext *ctx)
{
  CTX(ctx);

  if(_rpd_client.sock < 0) return 0;
  int ret = _rpd_client.Send();
  if(ret < 0) _rpd_client.Close();
  return ret;
}

int owlRPDRecv(OWLContext *ctx)
{
  CTX(ctx);

  if(_rpd_client.sock < 0) return 0;
  int ret = _rpd_client.Recv();
  if(ret < 0) _rpd_client.Close();
  return ret;
}

//// RPDClient ////

int _RPDClient::Open(const char *servername, const char *filename, int mode)
{
  Close();
  
  if(mode == OWL_RPD_SAVE)
    {
#ifdef WIN32
      fd = open(filename, O_WRONLY|O_CREAT|O_TRUNC|O_BINARY, 0644);
#else
      fd = open(filename, O_WRONLY|O_CREAT|O_TRUNC|O_LARGEFILE, 0644);
#endif
    }
  else if(mode == OWL_RPD_LOAD)
    {
#ifdef WIN32
      // don't forget to open file in binary mode %#@^$*(#%$#$!!!
      fd = open(filename, O_RDONLY|O_BINARY);
#else
      fd = open(filename, O_RDONLY|O_LARGEFILE);
#endif
    }
  else
    {
      cerr << "error: invalid RPD mode " << mode << endl;
      return -1;
    }

  if(fd < 0)
    {
      cerr << "error: could not open file " << filename << ": " << strerror(errno) << endl;
      return -2;
    }

  _mode = mode;
  
  clear();

#if 0
  // load file
  if(mode == OWL_RPD_LOAD)
    {
      // seek file
      int fsize = lseek(fd, 0, SEEK_END);
      if(fsize < 0 || lseek(fd, 0, SEEK_SET) < 0)
	{
	  cerr << "lseek failed: " << strerror(errno) << endl;
	  return -5;
	}
      
      // allocate space
      reserve(fsize);
      if(available() < (size_t)fsize)
	{
	  cerr << "failed to allocate " << fsize << " bytes: " << available() << endl;
	  return -6;
	}

      // read file
      cout << "reading file: " << filename << endl;
      while(1)
	{
	  int ret = read(fd, end(), available());
	  if(ret == 0) break;
	  if(ret < 0) return ret;
	  (*this) += ret, _read += ret;
	}
      cout << " read " << _read << " bytes" << endl;
    }
#endif

  nonexec(fd);

  // separate server name into name:port
  char name[1024] = "localhost";
  int port = 0;

  if(servername)
    {
      const char *ptr = strchr(servername, ':');
      int size = ptr ? ptr - servername : strlen(servername);
      
      if(size) memcpy(name, servername, size), name[size] = 0;
      if(ptr) sscanf(ptr, ":%d", &port);
    }

  sock = connect_tcp(name, 9000+port, 4*1000000);
  
  if(sock < 0)
    {
      cerr << "error: could not connect to " << servername << endl;
      return -3;
    }
  nonblock(sock);
  set_rcvbuf(sock, _tcp_rcvbuf_size);
  //cout << "RCVBUF=" << get_rcvbuf(sock) << endl;

  cout << "RPD: connect: " << sock << endl;

  int ret = tcp_send(sock, (char*)&mode, sizeof(mode));
  if(ret != sizeof(mode))
    {
      cerr << "error: failed to send mode" << endl;
      return -4;
    }
  
  if(mode == OWL_RPD_LOAD)
    {
      cout << "sending RPD header" << endl;
      ret = Send(10000, 0x100000);
      if(ret > 0) cout << " sent=" << ret << endl;
      else return ret;
    }

  cout << "RPD: opened with " << mode << endl;
  
  return 1;
}

void _RPDClient::Disconnect()
{
  if(sock > -1 && _mode == OWL_RPD_SAVE)
    {
      //cout << "rpd::disconnect" << endl;
      // set mode=0, works only in SAVE mode
      int mode = 0;
      int ret = tcp_send(sock, (char*)&mode, sizeof(mode));
      if(ret != sizeof(mode))
	{
	  cerr << "error: failed to send mode" << endl;
	  return;
	}
    }
}

void _RPDClient::Close()
{
  if(sock < 0) return;
  cout << "rpd close: " << sock << endl;
  if(sock > -1) closesocket(sock);
  if(fd > -1) close(fd);
  sock = -1;
  fd = -1;
  _mode = 0;
  clear();

  if(_write || _read || _send || _recv)
    cout << "rpd: write=" << _write << " read=" << _read << " send=" << _send << " recv=" << _recv 
         << " max_size=" << _max_size << endl;
  cout << "RPD: closed" << endl;

  _write = _read = _send = _recv = _max_size = 0;
}

int _RPDClient::Recv()
{
  if(_mode != OWL_RPD_SAVE) return -1;
  
  int ret = tcp_recv(sock, end(), available());

  if(ret < 0 && size() == 0) return ret;

  if(ret > 0) (*this) += ret, _recv += ret;

  if((int)size() > _max_size) _max_size = size();

  // write exactly one 'chunk' at a time
  if(ret < 0 || _rpd_chunk_size == 0)
    ret = write(fd, begin(), size());
  else if(size() > _rpd_chunk_size)
    ret = write(fd, begin(), _rpd_chunk_size);
  else
    ret = 0;
    
  if(ret < 0) return ret;
  
  if(ret > 0) (*this) -= ret, _write += ret;
  
  return ret;
}

int _RPDClient::Send(int retry, size_t count)
{
  if(_mode != OWL_RPD_LOAD) return -1;

  int ret = read(fd, end(), available());

  if(ret <= 0 && size() == 0) return ret ? ret : -1;

  if(ret > 0) (*this) += ret, _read += ret;

  ret = select(0, sock, 0);

  if(ret <= 0) return ret;

  if(count == 0 || count > size()) count = size();
  int size = 0;
  while(1)
    {
      ret = tcp_send(sock, begin(), count);
      if(ret > 0) size += ret, (*this) -= ret, _send += ret;
      if(ret < 0 || size >= (int)count || retry-- <= 0) break;
      else delay(1);
    }

  if(ret < 0) return size?size:ret;
  
  return size;
}
