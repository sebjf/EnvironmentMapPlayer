// libowlsock-st.cc
// network enabled OWL library (single thread)
// OWL v1.3

// include owl.h before libowlsock.cc to get CTX defines
#include "owl.h"

#include "libowlsock.cc"

OWLContext _default_ctx;
OWLContext *_ctx = &_default_ctx;

//// owl context ////

int owlSetContext(OWLContext *ctx)
{
  if(!ctx) return 0;
  _ctx = ctx;
  return 1;
}

//// owl ////

#define owlGetRigid owlGetRigids

int owlInit(const char *server, int flags)
{
  return owlInit(_ctx, server, flags);
}

void owlDone(void)
{
  owlDone(_ctx);
}

void owlSetFloat(OWLenum pname, float param)
{
  owlSetFloat(_ctx, pname, param);
}

void owlSetInteger(OWLenum pname, int param)
{
  owlSetInteger(_ctx, pname, param);
}

void owlSetFloatv(OWLenum pname, const float *param)
{
  owlSetFloatv(_ctx, pname, param);
}

void owlSetIntegerv(OWLenum pname, const int *param)
{
  owlSetIntegerv(_ctx, pname, param);
}

void owlSetString(OWLenum pname, const char *str)
{
  owlSetString(_ctx, pname, str);
}

void owlTracker(int tracker, OWLenum pname)
{
  owlTracker(_ctx, tracker, pname);
}

void owlTrackerf(int tracker, OWLenum pname, float param)
{
  owlTrackerf(_ctx, tracker, pname, param);
}

void owlTrackeri(int tracker, OWLenum pname, int param)
{
  owlTrackeri(_ctx, tracker, pname, param);
}

void owlTrackerfv(int tracker, OWLenum pname, const float *param)
{
  owlTrackerfv(_ctx, tracker, pname, param);
}

void owlTrackeriv(int tracker, OWLenum pname, const int *param)
{
  owlTrackeriv(_ctx, tracker, pname, param);
}

void owlMarker(int marker, OWLenum pname)
{
  owlMarker(_ctx, marker, pname);
}

void owlMarkerf(int marker, OWLenum pname, float param)
{
  owlMarkerf(_ctx, marker, pname, param);
}

void owlMarkeri(int marker, OWLenum pname, int param)
{
  owlMarkeri(_ctx, marker, pname, param);
}

void owlMarkerfv(int marker, OWLenum pname, const float *param)
{
  owlMarkerfv(_ctx, marker, pname, param);
}

void owlMarkeriv(int marker, OWLenum pname, const int *param)
{
  owlMarkeriv(_ctx, marker, pname, param);
}

void owlScale(float scale)
{
  owlScale(_ctx, scale);
}

void owlLoadPose(const float *pose)
{
  owlLoadPose(_ctx, pose);
}

int owlGetStatus(void)
{
  return owlGetStatus(_ctx);
}

int owlGetError(void)
{
  return owlGetError(_ctx);
}

OWLEvent owlPeekEvent(void)
{
  return owlPeekEvent(_ctx);
}

OWLEvent owlGetEvent(void)
{
  return owlGetEvent(_ctx);
}

int owlGetMarkers(OWLMarker *markers, uint_t count)
{
  return owlGetMarkers(_ctx, markers, count);
}

int owlGetRigids(OWLRigid *rigid, uint_t count)
{
  return owlGetRigids(_ctx, rigid, count);
}

int owlGetCameras(OWLCamera *cameras, uint_t count)
{
  return owlGetCameras(_ctx, cameras, count);
}

int owlGetPeaks(OWLPeak *peaks, uint_t count)
{
  return owlGetPeaks(_ctx, peaks, count);
}

int owlGetImages(OWLImage *images, uint_t count)
{
  return owlGetPeaks(_ctx, (OWLPeak*)images, count);
}

int owlGetDetectors(OWLDetectors *detectors, uint_t count)
{
  return owlGetDetectors(_ctx, detectors, count);
}

int owlGetPlanes(OWLPlane *planes, uint_t count)
{
  return owlGetPlanes(_ctx, planes, count);
}

int owlGetFloatv(OWLenum pname, float *param)
{
  return owlGetFloatv(_ctx, pname, param);
}

int owlGetIntegerv(OWLenum pname, int *param)
{
  return owlGetIntegerv(_ctx, pname, param);
}

int owlGetString(OWLenum pname, char *str)
{
  return owlGetString(_ctx, pname, str);
}

//// RPD ////

int owlRPDOpen(const char *servername, const char *filename, int mode)
{
  return owlRPDOpen(_ctx, servername, filename, mode);
}

void owlRPDClose()
{
  owlRPDClose(_ctx);
}

int owlRPDSend()
{
  return owlRPDSend(_ctx);
}

int owlRPDRecv()
{
  return owlRPDRecv(_ctx);
}
